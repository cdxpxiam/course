/* Student starting point. Complete the stage tasks; compare the diff only after attempting. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>
volatile uint32_t course_uptime;
int main(void){while(1){course_uptime++;}}
