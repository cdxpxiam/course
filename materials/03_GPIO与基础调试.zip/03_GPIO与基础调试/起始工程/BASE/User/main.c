/* Student starting point. Complete the stage tasks; compare the diff only after attempting. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>
volatile uint32_t course_uptime;
int main(void) {
    uint32_t last=0;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Tick_Init();Delay_Init();
    while(1) {course_uptime=Tick_Now();
        last=course_uptime;(void)last;
    }
}
