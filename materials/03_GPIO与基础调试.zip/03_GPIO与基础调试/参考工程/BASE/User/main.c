/* Stage reference implementation; compiled separately, hardware verification pending. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>
volatile uint32_t course_uptime;
static void LED_Init(void) {GPIO_InitTypeDef g;RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);GPIO_SetBits(GPIOC,GPIO_Pin_13);g.GPIO_Pin=GPIO_Pin_13;g.GPIO_Mode=GPIO_Mode_Out_OD;g.GPIO_Speed=GPIO_Speed_2MHz;GPIO_Init(GPIOC,&g);}
int main(void) {
    uint32_t last=0;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Tick_Init();Delay_Init();
    LED_Init();
    while(1) {course_uptime=Tick_Now();
        if((uint32_t)(course_uptime-last)>=500U) {last=course_uptime;GPIO_WriteBit(GPIOC,GPIO_Pin_13,(GPIO_ReadOutputDataBit(GPIOC,GPIO_Pin_13)==0)?Bit_SET:Bit_RESET);}
    }
}
