/* Student starting point. Complete the stage tasks; compare the diff only after attempting. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>
#include "MAX30102.h"
#include "Course_MAX.h"
#include "IR_Filter.h"
int main(void) {
    uint8_t id=0,failed=0,value=0;MAX30102_Status status;char line[100];
    uint32_t red=0,ir=0,seq=0,now=0,last_display=0,last_sample=0,last_retry=0;int got;
    float filtered=0;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Tick_Init();Delay_Init();
    OLED_Init();Serial_Init();MAX30102_BusInit();
    status=MAX30102_ReadReg(0xFF,&id);
    snprintf(line,sizeof(line),"# ID,status=%u,part=0x%02X\r\n",status,id);Serial_SendString(line);
    if(status!=MAX30102_OK || id!=0x15) {OLED_ShowString(1,1,"SENSOR ID FAIL");while(1){}}
    status=Course_Start(&failed);
    if(status) {snprintf(line,sizeof(line),"# CONFIG FAIL,%u,%u\r\n",status,failed);Serial_SendString(line);OLED_ShowString(1,1,"CONFIG FAIL");while(1){}}
    {const uint8_t regs[]={0x08,0x0A,0x0C,0x0D,0x09};const uint8_t expected[]={0,0x27,0x1F,0x1F,3};unsigned i;for(i=0;i<5;i++){status=MAX30102_ReadReg(regs[i],&value);snprintf(line,sizeof(line),"# REG,%02X,%02X,status=%u\r\n",regs[i],value,status);Serial_SendString(line);if(status || value!=expected[i]){OLED_ShowString(1,1,"READBACK FAIL");while(1){}}}}
    Serial_SendString("seq,ms,red,ir,filtered_x100\r\n");last_sample=Tick_Now();
    while(1) {
        now=Tick_Now();got=Course_Poll(&red,&ir);
        if(got<0) {Serial_SendString("# ACQUISITION ERROR/GAP; reset required\r\n");OLED_ShowString(4,1,"READ/GAP ERROR");while(1){}}
        if(got==1) {last_sample=now;seq++;
            filtered=IR_Filter(ir);
            snprintf(line,sizeof(line),"%lu,%lu,%lu,%lu,%ld\r\n",(unsigned long)seq,(unsigned long)now,(unsigned long)red,(unsigned long)ir,(long)(filtered*100.0f));Serial_SendString(line);
            if((uint32_t)(now-last_display)>=250U){last_display=now;OLED_ShowString(1,1,"RED:");OLED_ShowNum(1,5,red,6);OLED_ShowString(2,1,"IR:");OLED_ShowNum(2,4,ir,6);
            }
        }
        (void)last_retry;
    }
}
