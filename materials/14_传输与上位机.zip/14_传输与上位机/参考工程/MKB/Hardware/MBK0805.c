#include "stm32f10x.h"
#include "MBK0805.h"
#include "MBK_Protocol.h"
#include "Tick.h"
typedef struct { uint8_t byte;uint32_t time; } RxItem;
static volatile RxItem rx[128];
static volatile uint16_t head,tail;
static volatile uint8_t rx_fault;
static MBK_Parser parser;
static MBK_Data data;
static uint32_t last_tx,last_metrics,cal_started;
static uint8_t calibration[3],cal_pending,cal_active;
static uint8_t ppg_enabled=1;
void MBK_SetPPGEnabled(uint8_t enabled) { ppg_enabled=(enabled!=0); }
void MBK_Init(void)
{
    GPIO_InitTypeDef g;USART_InitTypeDef u;NVIC_InitTypeDef n;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
    g.GPIO_Pin=GPIO_Pin_2;g.GPIO_Mode=GPIO_Mode_AF_PP;g.GPIO_Speed=GPIO_Speed_50MHz;GPIO_Init(GPIOA,&g);
    g.GPIO_Pin=GPIO_Pin_3;g.GPIO_Mode=GPIO_Mode_IPU;GPIO_Init(GPIOA,&g);
    USART_StructInit(&u);u.USART_BaudRate=115200;USART_Init(USART2,&u);
    n.NVIC_IRQChannel=USART2_IRQn;n.NVIC_IRQChannelPreemptionPriority=1;
    n.NVIC_IRQChannelSubPriority=0;n.NVIC_IRQChannelCmd=ENABLE;NVIC_Init(&n);
    USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);USART_Cmd(USART2,ENABLE);
    data.cal_state=255;last_metrics=Tick_Now()-500U;last_tx=Tick_Now();
}
void USART2_IRQHandler(void)
{
    uint32_t sr=USART2->SR;
    if(sr&(USART_SR_RXNE|USART_SR_ORE|USART_SR_FE|USART_SR_NE|USART_SR_PE)) {
        uint8_t b=(uint8_t)USART2->DR;uint16_t next=(head+1U)&127U;
        if(sr&(USART_SR_ORE|USART_SR_FE|USART_SR_NE|USART_SR_PE)) {rx_fault=1;return;}
        if(next==tail) {rx_fault=1;return;}
        rx[head].byte=b;rx[head].time=Tick_Now();head=next;
    }
}
static void Send(uint8_t cmd,uint8_t a,uint8_t b,uint8_t c,uint32_t now)
{
    uint8_t frame[6],i;
    MBK_Request(cmd,a,b,c,frame);MBK_ParserStart(&parser,cmd,now);last_tx=now;
    for(i=0;i<6;i++) {while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET) {} USART_SendData(USART2,frame[i]);}
}
int MBK_Calibrate(uint8_t sys,uint8_t dia,uint8_t hr)
{
    if(cal_active || cal_pending || sys<40 || sys>220 || dia<40 || dia>=sys || hr<30 || hr>200) return 0;
    calibration[0]=sys;calibration[1]=dia;calibration[2]=hr;cal_pending=1;return 1;
}
const MBK_Data *MBK_GetData(void) { return &data; }
void MBK_Service(uint32_t now)
{
    uint8_t b;uint32_t time;
    if(rx_fault) {
        __disable_irq();tail=head;rx_fault=0;__enable_irq();
        MBK_ParserAbort(&parser);data.uart_errors++;data.hr_valid=0;data.bp_valid=0;
    }
    while(tail!=head) {
        b=rx[tail].byte;time=rx[tail].time;tail=(tail+1U)&127U;
        if(MBK_ParserFeed(&parser,b,time)) {
            uint8_t *f=parser.bytes;data.replies++;
            if(f[0]==0xFD) {
                data.hr=f[3];data.sys=f[1];data.dia=f[2];
                data.hr_valid=(f[3]>=30 && f[3]<=200);data.bp_valid=(uint8_t)MBK_MetricsValid(f);
                data.metric_time=time;data.metric_seen=1;
            } else if(f[0]==0xFC && f[1]==0) {
                data.ppg=((uint16_t)f[2]<<8)|f[3];data.ppg_time=time;data.ppg_seen=1;
            } else if(f[0]==0xFE && f[1]==0 && f[2]==0 && f[3]<=2) {
                data.cal_state=f[3];if(f[3]!=1) cal_active=0;
                else MBK_ParserStart(&parser,0xFE,time);
            }
        }
    }
    now=Tick_Now();
    if(MBK_ParserExpired(&parser,now)) {MBK_ParserAbort(&parser);if(!cal_active) data.timeouts++;}
    if((uint32_t)(now-data.metric_time)>3000U) {data.hr_valid=0;data.bp_valid=0;}
    if(cal_active) {
        if((uint32_t)(now-cal_started)>60000U) {cal_active=0;data.cal_state=254;MBK_ParserAbort(&parser);}
        else if(!parser.expected) MBK_ParserStart(&parser,0xFE,now);
        return;
    }
    if(parser.expected || (uint32_t)(now-last_tx)<20U) return;
    if(cal_pending) {
        cal_pending=0;cal_active=1;cal_started=now;data.cal_state=1;data.hr_valid=0;data.bp_valid=0;
        Send(0xFE,calibration[0],calibration[1],calibration[2],now);
    } else if((uint32_t)(now-last_metrics)>=500U) {last_metrics=now;Send(0xFD,0,0,0,now);}
    else if(ppg_enabled) Send(0xFC,0,0,0,now);
}
