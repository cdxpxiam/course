#ifndef MBK0805_H
#define MBK0805_H
#include <stdint.h>
typedef struct {
    uint8_t sys,dia,hr,hr_valid,bp_valid,cal_state;
    uint16_t ppg;
    uint32_t metric_time,ppg_time,replies,timeouts,uart_errors;
    uint8_t metric_seen,ppg_seen;
} MBK_Data;
void MBK_Init(void);
void MBK_Service(uint32_t now);
const MBK_Data *MBK_GetData(void);
int MBK_Calibrate(uint8_t sys,uint8_t dia,uint8_t hr);
void MBK_SetPPGEnabled(uint8_t enabled);
#endif
