#ifndef MBK_PROTOCOL_H
#define MBK_PROTOCOL_H
#include <stdint.h>
typedef struct {
    uint8_t expected,count,bytes[4];
    uint32_t started,last_byte;
} MBK_Parser;
void MBK_ParserStart(MBK_Parser *p,uint8_t command,uint32_t now);
void MBK_ParserAbort(MBK_Parser *p);
int MBK_ParserFeed(MBK_Parser *p,uint8_t byte,uint32_t now);
int MBK_ParserExpired(const MBK_Parser *p,uint32_t now);
int MBK_MetricsValid(const uint8_t *frame);
/* 0=OK, 1=zero/unavailable, 2=range, 3=order, 4=HR range. */
uint8_t MBK_BPReason(uint8_t sys,uint8_t dia,uint8_t hr);
void MBK_Request(uint8_t command,uint8_t a,uint8_t b,uint8_t c,uint8_t *out);
#endif
