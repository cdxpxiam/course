#include "Telemetry.h"
#include "MBK_Protocol.h"
#include <stdio.h>
uint16_t Telemetry_Format(const MBK_Data *d,uint32_t now,char *out,uint16_t capacity)
{
    int length;
    uint8_t fresh=d->metric_seen && (uint32_t)(now-d->metric_time)<=3000U;
    uint8_t active=fresh && d->cal_state!=1;
    uint8_t hv=active && d->hr_valid;
    uint8_t bv=active && d->bp_valid;
    uint8_t pv=d->ppg_seen && d->cal_state!=1 && (uint32_t)(now-d->ppg_time)<=200U;
    if(!out || !capacity) return 0;
    length=snprintf(out,capacity,"%lu,%u,%u,%u,%u,%u,%u,%u,NA,%lu,%lu,%lu,%u,%u,%u,%u,%u\r\n",
        (unsigned long)now,hv?d->hr:0,bv?d->sys:0,bv?d->dia:0,hv,bv,pv?d->ppg:0,pv,
        (unsigned long)d->replies,(unsigned long)d->timeouts,(unsigned long)d->uart_errors,d->cal_state,
        d->sys,d->dia,d->hr,fresh?MBK_BPReason(d->sys,d->dia,d->hr):5);
    if(length<0 || length>=capacity) {out[0]=0;return 0;}
    return (uint16_t)length;
}
