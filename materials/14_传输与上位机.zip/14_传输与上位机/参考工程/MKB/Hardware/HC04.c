#include "stm32f10x.h"
#include "HC04.h"
#define TX_SIZE 512U
#define TX_MASK (TX_SIZE-1U)
static volatile uint8_t tx[TX_SIZE];
static volatile uint16_t head,tail;
static volatile uint32_t dropped;
void HC04_Init(void)
{
    GPIO_InitTypeDef g;USART_InitTypeDef u;NVIC_InitTypeDef n;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);
    g.GPIO_Pin=GPIO_Pin_10;g.GPIO_Mode=GPIO_Mode_AF_PP;g.GPIO_Speed=GPIO_Speed_50MHz;GPIO_Init(GPIOB,&g);
    g.GPIO_Pin=GPIO_Pin_11;g.GPIO_Mode=GPIO_Mode_IPU;GPIO_Init(GPIOB,&g);
    USART_StructInit(&u);u.USART_BaudRate=HC04_BAUDRATE;
    /* Upload only; PC calibration commands remain on CH340 / USART1. */
    u.USART_Mode=USART_Mode_Tx;USART_Init(USART3,&u);
    head=0;tail=0;dropped=0;
    USART_ITConfig(USART3,USART_IT_TXE,DISABLE);
    n.NVIC_IRQChannel=USART3_IRQn;n.NVIC_IRQChannelPreemptionPriority=2;
    n.NVIC_IRQChannelSubPriority=1;n.NVIC_IRQChannelCmd=ENABLE;NVIC_Init(&n);
    USART_Cmd(USART3,ENABLE);
}
uint8_t HC04_SendFrame(const char *frame,uint16_t length)
{
    uint32_t mask;uint16_t free_count,i;
    if(!frame || !length) return 0;
    mask=__get_PRIMASK();__disable_irq();
    free_count=(uint16_t)((tail-head-1U)&TX_MASK);
    if(length>free_count) {dropped++;__set_PRIMASK(mask);return 0;}
    for(i=0;i<length;i++) {tx[head]=(uint8_t)frame[i];head=(head+1U)&TX_MASK;}
    USART_ITConfig(USART3,USART_IT_TXE,ENABLE);
    __set_PRIMASK(mask);return 1;
}
uint32_t HC04_GetDroppedFrames(void) {return dropped;}
void USART3_IRQHandler(void)
{
    if(USART_GetITStatus(USART3,USART_IT_TXE)!=RESET) {
        if(tail==head) USART_ITConfig(USART3,USART_IT_TXE,DISABLE);
        else {USART_SendData(USART3,tx[tail]);tail=(tail+1U)&TX_MASK;}
    }
}
