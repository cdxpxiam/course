#ifndef HC04_H
#define HC04_H
#include <stdint.h>
/* HC-04D transparent UART on USART3: PB10 TX, PB11 RX.
 * Set to the module's actual UART baud; do not send speculative AT commands. */
#ifndef HC04_BAUDRATE
#define HC04_BAUDRATE 9600UL
#endif
#define HC04_REPORT_INTERVAL_MS 500UL
void HC04_Init(void);
/* Commit a complete text frame or drop it; never wait for radio pairing. */
uint8_t HC04_SendFrame(const char *frame,uint16_t length);
uint32_t HC04_GetDroppedFrames(void);
#endif
