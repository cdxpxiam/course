#include "MBK_Protocol.h"
/* Standard UART: 6-byte requests, 4-byte replies; no CRC. */
void MBK_ParserStart(MBK_Parser *p,uint8_t cmd,uint32_t now)
{ p->expected=cmd;p->count=0;p->started=now;p->last_byte=now; }
void MBK_ParserAbort(MBK_Parser *p) { p->expected=0;p->count=0; }
int MBK_ParserExpired(const MBK_Parser *p,uint32_t now)
{ return p->expected && ((uint32_t)(now-p->started)>=50U ||
    (p->count && (uint32_t)(now-p->last_byte)>=10U)); }
int MBK_ParserFeed(MBK_Parser *p,uint8_t byte,uint32_t now)
{
    if(MBK_ParserExpired(p,now)) MBK_ParserAbort(p);
    if(!p->expected) return 0;
    if(!p->count && byte!=p->expected) return 0;
    /* PPG payload may equal a header; never restart inside a frame. */
    p->bytes[p->count++]=byte;p->last_byte=now;
    if(p->count==4) {MBK_ParserAbort(p);return 1;}return 0;
}
int MBK_MetricsValid(const uint8_t *f)
{ return f[0]==0xFD && MBK_BPReason(f[1],f[2],f[3])==0; }
uint8_t MBK_BPReason(uint8_t sys,uint8_t dia,uint8_t hr)
{
    if(!sys || !dia) return 1;
    if(sys<40 || sys>220 || dia<40 || dia>220) return 2;
    if(sys<=dia) return 3;
    if(hr<30 || hr>200) return 4;
    return 0;
}
void MBK_Request(uint8_t cmd,uint8_t a,uint8_t b,uint8_t c,uint8_t *out)
{ out[0]=cmd;out[1]=a;out[2]=b;out[3]=c;out[4]=0;out[5]=0; }
