#ifndef MBK_TELEMETRY_H
#define MBK_TELEMETRY_H
#include "MBK0805.h"
/* Maximum standard 17-column frame is below 160 bytes, including CRLF/NUL. */
#define TELEMETRY_BUFFER_SIZE 160U
uint16_t Telemetry_Format(const MBK_Data *data,uint32_t now,char *out,uint16_t capacity);
#endif
