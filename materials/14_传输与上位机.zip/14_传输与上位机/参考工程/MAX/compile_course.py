"""Compile a self-contained course project; never downloads or flashes firmware."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess
import xml.etree.ElementTree as ET

def build(project,tool,cache=None):
    project=Path(project).resolve();tool=Path(tool).resolve()
    info=json.loads((project/'sources.json').read_text(encoding='utf-8'))
    objdir=project/'Objects';objdir.mkdir(exist_ok=True)
    logs=[];objects=[];warnings=0
    includes=['Start','Library','User','System','Hardware','Algorithm']
    def run(args):
        nonlocal warnings
        p=subprocess.run([str(a) for a in args],cwd=project,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        output=p.stdout.decode('utf-8',errors='replace');logs.append(output);warnings+=output.lower().count('warning:')
        if p.returncode:raise RuntimeError(output[-5000:])
    try:
        for source in info['sources']:
            p=project/source;obj=objdir/(p.stem+'.o')
            # Cache is shared only within one verification run and hashes all headers.
            h=hashlib.sha256(p.read_bytes())
            for header in sorted(project.rglob('*.h')):h.update(header.relative_to(project).as_posix().encode());h.update(header.read_bytes())
            key=h.hexdigest();cached=Path(cache)/(key+'.o') if cache else None
            if cached and cached.exists():obj.write_bytes(cached.read_bytes())
            elif p.suffix=='.s':run([tool/'armasm.exe','--cpu','Cortex-M3','--pd','__MICROLIB SETA 1',source,'-o',obj])
            else:run([tool/'armcc.exe','--cpu','Cortex-M3','--c99','--library_type=microlib','-O1','--split_sections','-g','-DSTM32F10X_MD','-DUSE_STDPERIPH_DRIVER',*['-I'+x for x in includes],'-c',source,'-o',obj])
            if cached and not cached.exists():cached.parent.mkdir(exist_ok=True,parents=True);cached.write_bytes(obj.read_bytes())
            objects.append(obj)
        scatter=objdir/'firmware.sct';scatter.write_text('LR_IROM1 0x08000000 0x10000 {\n ER_IROM1 0x08000000 0x10000 {\n *.o (RESET, +First)\n *(InRoot$$Sections)\n .ANY (+RO)\n }\n RW_IRAM1 0x20000000 0x5000 {\n .ANY (+RW +ZI)\n }\n}\n')
        run([tool/'armlink.exe','--cpu','Cortex-M3','--library_type=microlib','--strict','--scatter',scatter,'--map','--info=sizes','--list',objdir/'course.map','-o',objdir/'course.axf',*objects])
        run([tool/'fromelf.exe','--i32combined','--output',objdir/'course.hex',objdir/'course.axf'])
        result={'compiled':True,'linked':True,'hex_generated':True,'hardware_tested':False,'warnings_in_compilation_output':warnings,'hex_sha256':hashlib.sha256((objdir/'course.hex').read_bytes()).hexdigest()}
    except Exception as e:result={'compiled':False,'error':str(e),'hardware_tested':False}
    (project/'build.log').write_text('\n'.join(logs),encoding='utf-8')
    (project/'build_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--keil-bin',default=os.environ.get('KEIL_BIN',r'D:\Keil_v5\ARM\ARMCC\bin'));a=p.parse_args()
    result=build(Path(__file__).resolve().parent,a.keil_bin);print(json.dumps(result,ensure_ascii=False));raise SystemExit(0 if result['compiled'] else 1)
