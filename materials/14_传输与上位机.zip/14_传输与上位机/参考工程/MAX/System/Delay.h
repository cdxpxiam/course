#ifndef COURSE_DELAY_H
#define COURSE_DELAY_H
#include <stdint.h>
void Delay_Init(void);void Delay_us(uint32_t us);void Delay_ms(uint32_t ms);void Delay_s(uint32_t s);
#endif
