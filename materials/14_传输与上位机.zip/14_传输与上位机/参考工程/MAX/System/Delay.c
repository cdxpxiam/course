#include "stm32f10x.h"
#include "Delay.h"
/* DWT cycle counter keeps SysTick free for the 1-ms course clock. */
#define DWT_CTRL (*(volatile uint32_t *)0xE0001000UL)
#define DWT_CYCCNT (*(volatile uint32_t *)0xE0001004UL)
void Delay_Init(void) { CoreDebug->DEMCR |= 0x01000000UL; DWT_CYCCNT=0; DWT_CTRL|=1U; }
void Delay_us(uint32_t us) {
    uint32_t start,cycles,part;
    while(us) { part=us>1000U?1000U:us;cycles=(SystemCoreClock/1000000U)*part;
        start=DWT_CYCCNT;while((uint32_t)(DWT_CYCCNT-start)<cycles){} us-=part; }
}
void Delay_ms(uint32_t ms) {while(ms--) Delay_us(1000);}
void Delay_s(uint32_t s) {while(s--) Delay_ms(1000);}
