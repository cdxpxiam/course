#include "HC05.h"
#include <stdio.h>

#define HC05_TX_SIZE 128U
#define HC05_TX_MASK (HC05_TX_SIZE - 1U)

static volatile uint8_t tx_buffer[HC05_TX_SIZE];
static volatile uint16_t tx_head = 0;
static volatile uint16_t tx_tail = 0;
static volatile uint32_t dropped_frames = 0;

void HC05_Init(void)
{
    GPIO_InitTypeDef gpio;
    USART_InitTypeDef uart;
    NVIC_InitTypeDef interrupt;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    gpio.GPIO_Pin = GPIO_Pin_2;
    gpio.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio);

    gpio.GPIO_Pin = GPIO_Pin_3;
    gpio.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &gpio);

    USART_StructInit(&uart);
    uart.USART_BaudRate = HC05_UART_BAUDRATE;
    uart.USART_WordLength = USART_WordLength_8b;
    uart.USART_StopBits = USART_StopBits_1;
    uart.USART_Parity = USART_Parity_No;
    uart.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    uart.USART_Mode = USART_Mode_Tx;
    USART_Init(USART2, &uart);

    USART_ITConfig(USART2, USART_IT_TXE, DISABLE);
    tx_head = 0;
    tx_tail = 0;
    dropped_frames = 0;

    /* Reuse Serial_Init's existing NVIC grouping; do not change it here. */
    interrupt.NVIC_IRQChannel = USART2_IRQn;
    interrupt.NVIC_IRQChannelPreemptionPriority = 2;
    interrupt.NVIC_IRQChannelSubPriority = 0;
    interrupt.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&interrupt);
    USART_Cmd(USART2, ENABLE);
}

static uint8_t HC05_QueueFrame(const char *text, uint16_t length)
{
    uint32_t interrupt_mask;
    uint16_t free_count;
    uint16_t i;

    interrupt_mask = __get_PRIMASK();
    __disable_irq();
    free_count = (uint16_t)((tx_tail - tx_head - 1U) & HC05_TX_MASK);
    if (length > free_count)
    {
        dropped_frames++;
        __set_PRIMASK(interrupt_mask);
        return 0;
    }

    /* Commit a complete frame or no bytes at all. */
    for (i = 0; i < length; i++)
    {
        tx_buffer[tx_head] = (uint8_t)text[i];
        tx_head = (uint16_t)((tx_head + 1U) & HC05_TX_MASK);
    }
    USART_ITConfig(USART2, USART_IT_TXE, ENABLE);
    __set_PRIMASK(interrupt_mask);
    return 1;
}

uint8_t HC05_SendMetrics(uint16_t bpm,
                         uint16_t spo2_tenths,
                         uint8_t hr_valid,
                         uint8_t spo2_valid,
                         uint8_t state,
                         uint32_t sequence)
{
    /* Max 33 bytes incl CRLF and NUL with bounded uint16/uint32 inputs. */
    char frame[48];
    int length;

    hr_valid = (uint8_t)(hr_valid != 0 && bpm != 0);
    spo2_valid = (uint8_t)(spo2_valid != 0 && spo2_tenths <= 1000U);
    if (!hr_valid) bpm = 0;
    if (!spo2_valid) spo2_tenths = 0;
    if (state > HC05_STATE_ERROR) state = HC05_STATE_ERROR;

    length = sprintf(frame, "%u,%u.%u,%u,%u,%u,%lu\r\n",
                     (unsigned int)bpm,
                     (unsigned int)(spo2_tenths / 10U),
                     (unsigned int)(spo2_tenths % 10U),
                     (unsigned int)hr_valid,
                     (unsigned int)spo2_valid,
                     (unsigned int)state,
                     (unsigned long)sequence);
    return HC05_QueueFrame(frame, (uint16_t)length);
}

uint32_t HC05_GetDroppedFrames(void)
{
    return dropped_frames;
}

void USART2_IRQHandler(void)
{
    if (USART_GetITStatus(USART2, USART_IT_TXE) != RESET)
    {
        if (tx_tail != tx_head)
        {
            USART_SendData(USART2, tx_buffer[tx_tail]);
            tx_tail = (uint16_t)((tx_tail + 1U) & HC05_TX_MASK);
        }
        if (tx_tail == tx_head)
        {
            USART_ITConfig(USART2, USART_IT_TXE, DISABLE);
        }
    }
}
