#include "Course_MAX.h"
#include "MAX30102.h"
#include "Tick.h"
uint32_t Course_Loss=0;
MAX30102_Status Course_Start(uint8_t *failed) {
    MAX30102_Status s;uint8_t value;uint32_t start;
    s=MAX30102_WriteReg(0x09,0x40);if(s) return s;
    start=Tick_Now();
    do {s=MAX30102_ReadReg(0x09,&value);if(s) return s;
        if((uint32_t)(Tick_Now()-start)>100U) return MAX30102_ERR_SCL_TIMEOUT;
    } while(value&0x40);
    return MAX30102_Config(failed);
}
/* 1=new pair, 0=empty, -1=I2C error, -2=gap/overflow discarded. */
int Course_Poll(uint32_t *red,uint32_t *ir) {
    uint8_t wr,rd,ov,flags;MAX30102_Status s;
    s=MAX30102_ReadReg(0x05,&ov);if(s) return -1;
    s=MAX30102_ReadReg(0x04,&wr);if(s) return -1;
    s=MAX30102_ReadReg(0x06,&rd);if(s) return -1;
    if(ov&31U) {
        s=MAX30102_WriteReg(0x04,0);if(s) return -1;
        s=MAX30102_WriteReg(0x05,0);if(s) return -1;
        s=MAX30102_WriteReg(0x06,0);if(s) return -1;
        Course_Loss++;return -2;
    }
    if((wr&31U)==(rd&31U)) {
        s=MAX30102_ReadReg(0x00,&flags);if(s) return -1;
        if(!(flags&0x80U)) return 0;
    }
    s=MAX30102_ReadFIFO(red,ir);return s?-1:1;
}
