#ifndef MAX30102_H
#define MAX30102_H

#include "stm32f10x.h"

typedef enum
{
    MAX30102_OK = 0,
    MAX30102_ERR_BUS_BUSY = 1,
    MAX30102_ERR_SCL_TIMEOUT = 2,
    MAX30102_ERR_ADDR_WRITE_NACK = 3,
    MAX30102_ERR_REG_NACK = 4,
    MAX30102_ERR_ADDR_READ_NACK = 5,
    MAX30102_ERR_ARGUMENT = 6,
	MAX30102_ERR_DATA_NACK = 7
} MAX30102_Status;

void MAX30102_BusInit(void);
MAX30102_Status MAX30102_ReadReg(uint8_t reg, uint8_t *value);
MAX30102_Status MAX30102_WriteReg(uint8_t reg, uint8_t data);
MAX30102_Status MAX30102_Config(uint8_t *fail_reg);
MAX30102_Status MAX30102_ReadBytes(uint8_t reg,
                                  uint8_t *data,
                                  uint8_t len);
MAX30102_Status MAX30102_ReadFIFO(uint32_t *red, uint32_t *ir);

#endif
