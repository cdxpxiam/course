#include "stm32f10x.h"
#include "Serial.h"
static volatile char rx[128];
static volatile unsigned head,tail;
static volatile uint8_t fault;
void Serial_Init(void)
{
    GPIO_InitTypeDef g;USART_InitTypeDef u;NVIC_InitTypeDef n;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_USART1,ENABLE);
    g.GPIO_Pin=GPIO_Pin_9;g.GPIO_Mode=GPIO_Mode_AF_PP;g.GPIO_Speed=GPIO_Speed_50MHz;GPIO_Init(GPIOA,&g);
    g.GPIO_Pin=GPIO_Pin_10;g.GPIO_Mode=GPIO_Mode_IPU;GPIO_Init(GPIOA,&g);
    USART_StructInit(&u);u.USART_BaudRate=115200;USART_Init(USART1,&u);
    n.NVIC_IRQChannel=USART1_IRQn;n.NVIC_IRQChannelPreemptionPriority=2;
    n.NVIC_IRQChannelSubPriority=0;n.NVIC_IRQChannelCmd=ENABLE;NVIC_Init(&n);
    USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);USART_Cmd(USART1,ENABLE);
}
void USART1_IRQHandler(void)
{
    uint32_t sr=USART1->SR;
    if(sr&(USART_SR_RXNE|USART_SR_ORE|USART_SR_FE|USART_SR_NE|USART_SR_PE)) {
        char b=(char)USART1->DR;unsigned next=(head+1U)&127U;
        if(sr&(USART_SR_ORE|USART_SR_FE|USART_SR_NE|USART_SR_PE)) {fault=1;return;}
        if(next==tail) {fault=1;return;}rx[head]=b;head=next;
    }
}
void Serial_SendString(const char *s)
{ while(*s) {while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET) {} USART_SendData(USART1,(uint8_t)*s++);} }
int Serial_ReadLine(char *out,unsigned size)
{
    static char line[64];static unsigned length;static uint8_t discard;
    if(fault) {__disable_irq();tail=head;fault=0;__enable_irq();length=0;discard=1;}
    while(tail!=head) {
        char c=rx[tail];tail=(tail+1U)&127U;
        if(c=='\r') continue;
        if(c=='\n') {
            unsigned i;
            if(discard) {discard=0;length=0;continue;}
            if(length+1U>size) {length=0;continue;}
            for(i=0;i<length;i++) out[i]=line[i];
            out[length]=0;length=0;return 1;
        }
        if(!discard) {if(length<sizeof(line)-1U) line[length++]=c;else {discard=1;length=0;}}
    }
    return 0;
}
