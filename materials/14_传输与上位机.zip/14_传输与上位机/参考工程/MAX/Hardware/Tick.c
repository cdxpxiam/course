#include "stm32f10x.h"
#include "Tick.h"
static volatile uint32_t milliseconds;
void SysTick_Handler(void) { milliseconds++; }
void Tick_Init(void) { SystemCoreClockUpdate();SysTick_Config(SystemCoreClock/1000U); }
uint32_t Tick_Now(void) { return milliseconds; }
void Tick_Wait(uint32_t ms) { uint32_t t=Tick_Now();while((uint32_t)(Tick_Now()-t)<ms) {} }
