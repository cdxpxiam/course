#ifndef HC05_H
#define HC05_H

#include "stm32f10x.h"

/* Must match the module's DATA-mode UART setting, not its AT-mode baud. */
#ifndef HC05_UART_BAUDRATE
#define HC05_UART_BAUDRATE 115200UL
#endif

#define HC05_STATE_NO_FINGER  0U
#define HC05_STATE_SETTLING   1U
#define HC05_STATE_DETECTING  2U
#define HC05_STATE_MEASURING  3U
#define HC05_STATE_ERROR      4U

/* USART2, PA2 TX -> HC05 RXD. PA3 reserved as input for HC05 TXD.
 * USART1/CH340 remains independent. No RX commands or AT reconfiguration. */
void HC05_Init(void);

/* CSV: bpm,spo2(with one decimal),hr_valid,spo2_valid,state,sequence\r\n.
 * spo2_tenths=996 means 99.6%. Returns 1 when queued, 0 when queue full.
 * Queued means local UART acceptance, not confirmation of wireless receipt. */
uint8_t HC05_SendMetrics(uint16_t bpm,
                         uint16_t spo2_tenths,
                         uint8_t hr_valid,
                         uint8_t spo2_valid,
                         uint8_t state,
                         uint32_t sequence);
uint32_t HC05_GetDroppedFrames(void);

#endif
