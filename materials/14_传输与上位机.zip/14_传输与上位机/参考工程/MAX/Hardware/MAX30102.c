#include "MAX30102.h"
#include "Delay.h"

/* Dedicated bus: PB10 = SCL, PB11 = SDA. External pull-ups required. */
#define SCL_PIN GPIO_Pin_10
#define SDA_PIN GPIO_Pin_11
#define ADDRESS_WRITE 0xAE
#define ADDRESS_READ  0xAF
#define HALF_PERIOD_US 5
#define SCL_WAIT_COUNT 200

static void BusDelay(void)
{
    Delay_us(HALF_PERIOD_US);
}

static void SDA_Write(uint8_t high)
{
    GPIO_WriteBit(GPIOB, SDA_PIN, high ? Bit_SET : Bit_RESET);
}

static uint8_t SDA_Read(void)
{
    return GPIO_ReadInputDataBit(GPIOB, SDA_PIN);
}

static void SCL_Low(void)
{
    GPIO_ResetBits(GPIOB, SCL_PIN);
}

/* Setting an open-drain output high releases the line. */
static MAX30102_Status SCL_High(void)
{
    uint16_t count;
    GPIO_SetBits(GPIOB, SCL_PIN);
    for (count = 0; count < SCL_WAIT_COUNT; count++)
    {
        if (GPIO_ReadInputDataBit(GPIOB, SCL_PIN) != 0)
        {
            BusDelay();
            return MAX30102_OK;
        }
        Delay_us(5);
    }
    return MAX30102_ERR_SCL_TIMEOUT;
}

void MAX30102_BusInit(void)
{
    GPIO_InitTypeDef gpio;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    /* Set output latches before switching the pins to output mode. */
    GPIO_SetBits(GPIOB, SCL_PIN | SDA_PIN);
    gpio.GPIO_Pin = SCL_PIN | SDA_PIN;
    gpio.GPIO_Mode = GPIO_Mode_Out_OD;
    gpio.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOB, &gpio);
    BusDelay();
}

/* Also used for repeated START; does not insert a STOP. */
static MAX30102_Status I2C_Start(void)
{
    MAX30102_Status status;
    SDA_Write(1);
    BusDelay();
    status = SCL_High();
    if (status != MAX30102_OK) return status;
    if (SDA_Read() == 0) return MAX30102_ERR_BUS_BUSY;
    SDA_Write(0);
    BusDelay();
    SCL_Low();
    BusDelay();
    return MAX30102_OK;
}

static MAX30102_Status I2C_Stop(void)
{
    uint16_t count;
    MAX30102_Status status;

    SCL_Low();
    SDA_Write(0);
    BusDelay();

    status = SCL_High();

    /* 无论 SCL 是否成功升高，都释放 SDA */
    SDA_Write(1);

    if (status != MAX30102_OK)
    {
        return status;
    }

    /* 等待 SDA 真正回到高电平，等待次数有限 */
    for (count = 0; count < SCL_WAIT_COUNT; count++)
    {
        if (SDA_Read() != 0)
        {
            BusDelay();
            return MAX30102_OK;
        }

        Delay_us(5);
    }

    return MAX30102_ERR_BUS_BUSY;
}

/* Sends eight bits, then samples the slave ACK on the ninth clock. */
static MAX30102_Status I2C_SendByte(uint8_t data, uint8_t *acked)
{
    uint8_t bit;
    MAX30102_Status status;
    for (bit = 0; bit < 8; bit++)
    {
        SDA_Write((data & 0x80) != 0);
        BusDelay();
        status = SCL_High();
        if (status != MAX30102_OK) return status;
        SCL_Low();
        BusDelay();
        data <<= 1;
    }
    SDA_Write(1);
    BusDelay();
    status = SCL_High();
    if (status != MAX30102_OK) return status;
    *acked = (SDA_Read() == 0);
    SCL_Low();
    BusDelay();
    return MAX30102_OK;
}

/* ack = 1 sends ACK; ack = 0 sends NACK after the final byte. */
static MAX30102_Status I2C_SendAck(uint8_t ack)
{
    MAX30102_Status status;
    SDA_Write(ack ? 0 : 1);
    BusDelay();
    status = SCL_High();
    SCL_Low();
    BusDelay();
    SDA_Write(1);
    return status;
}

static MAX30102_Status I2C_ReadByte(uint8_t *data, uint8_t ack)
{
    uint8_t bit;
    uint8_t result = 0;
    MAX30102_Status status;
    SDA_Write(1);
    for (bit = 0; bit < 8; bit++)
    {
        BusDelay();
        status = SCL_High();
        if (status != MAX30102_OK) return status;
        result = (uint8_t)((result << 1) | SDA_Read());
        SCL_Low();
        BusDelay();
    }
    status = I2C_SendAck(ack);
    if (status == MAX30102_OK) *data = result;
    return status;
}

static MAX30102_Status I2C_ReadBytes(uint8_t *data, uint8_t len)
{
    uint8_t i;
    uint8_t ack;
    MAX30102_Status status;

    if (data == 0 || len == 0)
    {
        return MAX30102_ERR_ARGUMENT;
    }

    for (i = 0; i < len; i++)
    {
        ack = (i == len - 1) ? 0 : 1;

        status = I2C_ReadByte(&data[i], ack);
        if (status != MAX30102_OK)
        {
            return status;
        }
    }

    return MAX30102_OK;
}

MAX30102_Status MAX30102_ReadBytes(uint8_t reg,
                                  uint8_t *data,
                                  uint8_t len)
{
    uint8_t acked;
    MAX30102_Status status;
    MAX30102_Status stop_status;

    if (data == 0 || len == 0)
    {
        return MAX30102_ERR_ARGUMENT;
    }

    status = I2C_Start();
    if (status != MAX30102_OK)
    {
        GPIO_SetBits(GPIOB, SCL_PIN | SDA_PIN);
        return status;
    }

    /* 选择设备，先写寄存器地址 */
    status = I2C_SendByte(ADDRESS_WRITE, &acked);
    if (status != MAX30102_OK) goto finish;
    if (!acked)
    {
        status = MAX30102_ERR_ADDR_WRITE_NACK;
        goto finish;
    }

    status = I2C_SendByte(reg, &acked);
    if (status != MAX30102_OK) goto finish;
    if (!acked)
    {
        status = MAX30102_ERR_REG_NACK;
        goto finish;
    }

    /* 重复开始，切换为读取 */
    status = I2C_Start();
    if (status != MAX30102_OK) goto finish;

    status = I2C_SendByte(ADDRESS_READ, &acked);
    if (status != MAX30102_OK) goto finish;
    if (!acked)
    {
        status = MAX30102_ERR_ADDR_READ_NACK;
        goto finish;
    }

    /* 调用你刚写好的连续接收函数 */
    status = I2C_ReadBytes(data, len);

finish:
    stop_status = I2C_Stop();

    if (status == MAX30102_OK)
    {
        status = stop_status;
    }

    return status;
}

MAX30102_Status MAX30102_ReadFIFO(uint32_t *red, uint32_t *ir)
{
    uint8_t data[6];
    MAX30102_Status status;

    if (red == 0 || ir == 0)
    {
        return MAX30102_ERR_ARGUMENT;
    }

    /* 同一次通信中，从 FIFO 接收六个字节 */
    status = MAX30102_ReadBytes(0x07, data, 6);
    if (status != MAX30102_OK)
    {
        return status;
    }

    /* 前三个字节拼成 RED */
    *red = ((uint32_t)data[0] << 16)
         | ((uint32_t)data[1] << 8)
         |  (uint32_t)data[2];

    /* 后三个字节拼成 IR */
    *ir = ((uint32_t)data[3] << 16)
        | ((uint32_t)data[4] << 8)
        |  (uint32_t)data[5];

    /* 只保留有效的 18 位 */
    *red &= 0x3FFFF;
    *ir  &= 0x3FFFF;

    return MAX30102_OK;
}

MAX30102_Status MAX30102_ReadReg(uint8_t reg, uint8_t *value)
{
    uint8_t acked;
    uint8_t result;
    MAX30102_Status status;
    MAX30102_Status stop_status;
    if (value == 0) return MAX30102_ERR_ARGUMENT;

    status = I2C_Start();
    if (status != MAX30102_OK)
    {
        GPIO_SetBits(GPIOB, SCL_PIN | SDA_PIN);
        return status;
    }
    status = I2C_SendByte(ADDRESS_WRITE, &acked);
    if (status != MAX30102_OK) goto finish;
    if (!acked) { status = MAX30102_ERR_ADDR_WRITE_NACK; goto finish; }

    status = I2C_SendByte(reg, &acked);
    if (status != MAX30102_OK) goto finish;
    if (!acked) { status = MAX30102_ERR_REG_NACK; goto finish; }

    status = I2C_Start();
    if (status != MAX30102_OK) goto finish;
    status = I2C_SendByte(ADDRESS_READ, &acked);
    if (status != MAX30102_OK) goto finish;
    if (!acked) { status = MAX30102_ERR_ADDR_READ_NACK; goto finish; }

    status = I2C_ReadByte(&result, 0);

finish:
    stop_status = I2C_Stop();
    if (status == MAX30102_OK) status = stop_status;
    if (status == MAX30102_OK) *value = result;
    return status;
}

MAX30102_Status MAX30102_WriteReg(uint8_t reg, uint8_t data)
{
    uint8_t acked;
    MAX30102_Status status;
    MAX30102_Status stop_status;

    status = I2C_Start();
    if (status != MAX30102_OK)
    {
        GPIO_SetBits(GPIOB, SCL_PIN | SDA_PIN);
        return status;
    }

    /* 1. 发送设备写地址 */
    status = I2C_SendByte(ADDRESS_WRITE, &acked);
    if (status != MAX30102_OK) goto finish;
    if (!acked)
    {
        status = MAX30102_ERR_ADDR_WRITE_NACK;
        goto finish;
    }

    /* 2. 发送寄存器地址 */
    status = I2C_SendByte(reg, &acked);
    if (status != MAX30102_OK) goto finish;
    if (!acked)
    {
        status = MAX30102_ERR_REG_NACK;
        goto finish;
    }

    /* 3. 发送要写入的数据 */
    status = I2C_SendByte(data, &acked);
    if (status != MAX30102_OK) goto finish;
    if (!acked)
    {
        status = MAX30102_ERR_DATA_NACK;
        goto finish;
    }

finish:
    stop_status = I2C_Stop();

    /* 前面成功时，再检查 STOP 是否成功 */
    if (status == MAX30102_OK)
    {
        status = stop_status;
    }

    return status;
}

MAX30102_Status MAX30102_Config(uint8_t *fail_reg)
{
	static const uint8_t config[][2] =
    {
        {0x02, 0x00}, /* 关闭中断，先使用轮询 */
        {0x03, 0x00},

        {0x04, 0x00}, /* FIFO 写指针清零 */
        {0x05, 0x00}, /* FIFO 溢出计数清零 */
        {0x06, 0x00}, /* FIFO 读指针清零 */

        {0x08, 0x00}, /* 不平均、不覆盖 */
        {0x0A, 0x27}, /* 采样参数 */
        {0x0C, 0x1F}, /* 红光电流 */
        {0x0D, 0x1F}, /* 红外电流 */

        {0x09, 0x03}  /* 最后启动采样 */
    };
	uint8_t i ;
	MAX30102_Status status;
	
	for(i = 0; i < sizeof(config)/sizeof(config[0]); i++)
	{
		status = MAX30102_WriteReg(config[i][0], config[i][1]);
		if(status != MAX30102_OK)
		{
			*fail_reg = config [i][0];
			return status ;
		}
	}
	return MAX30102_OK ;
}
