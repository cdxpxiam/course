#ifndef SERIAL_H
#define SERIAL_H
void Serial_Init(void);
void Serial_SendString(const char *s);
int Serial_ReadLine(char *out,unsigned size);
#endif
