#ifndef TICK_H
#define TICK_H
#include <stdint.h>
void Tick_Init(void);
uint32_t Tick_Now(void);
void Tick_Wait(uint32_t ms);
#endif
