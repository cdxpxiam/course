#include "MAX30102.h"
extern uint32_t Course_Loss;
MAX30102_Status Course_Start(uint8_t *failed);
int Course_Poll(uint32_t *red,uint32_t *ir);
