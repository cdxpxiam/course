#ifndef IR_MOTION_H
#define IR_MOTION_H

#include "stm32f10x.h"

void IR_Motion_Init(void);
uint8_t IR_Motion_Process(uint32_t ir, uint8_t finger_present);

#endif
