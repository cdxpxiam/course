#include "HeartRate.h"

#define HR_AVG_COUNT 5

static uint32_t interval_buffer[HR_AVG_COUNT];
static uint32_t interval_sum = 0;
static uint8_t interval_index = 0;
static uint8_t interval_count = 0;

static uint8_t abnormal_count = 0;

/* 是否已经经过负向门槛 */
static uint8_t armed = 0;

/* 已处理的采样点数量 */
static uint32_t sample_count = 0;

/* 当前心率 */
static uint16_t current_bpm = 0;

/* 间隔时间 */
static uint32_t last_beat_sample = 0;
static uint8_t have_last_beat = 0;

static uint32_t last_interval = 0;





void HeartRate_Init(void)
{
    uint8_t i;

    sample_count = 0;
    current_bpm = 0;
    armed = 0;
    last_beat_sample = 0;
    have_last_beat = 0;
    last_interval = 0;

    interval_sum = 0;
    interval_index = 0;
    interval_count = 0;
	abnormal_count = 0;

    for (i = 0; i < HR_AVG_COUNT; i++)

    {
        interval_buffer[i] = 0;
    }
}

uint8_t HeartRate_Process(float sample)
{
    uint32_t interval;
    uint32_t numerator;
    uint8_t i;
	uint32_t average_interval;

    sample_count++;
	
	if (have_last_beat != 0 &&
    (sample_count - last_beat_sample) > 200)
	{
		abnormal_count = 0;
		current_bpm = 0;
		have_last_beat = 0;
		last_beat_sample = 0;
		last_interval = 0;
		armed = 0;
	
		/* 清空之前的平均间隔 */
		interval_sum = 0;
		interval_index = 0;
		interval_count = 0;
	
		for (i = 0; i < HR_AVG_COUNT; i++)
		{
			interval_buffer[i] = 0;
		}
	}

    if (sample < -50.0f)
    {
        armed = 1;
    }

    if (armed == 1 && sample > 50.0f)
    {
        armed = 0;

        /* 第一次只记录位置 */
        if (have_last_beat == 0)
        {
            last_beat_sample = sample_count;
            have_last_beat = 1;
            return 1;
        }

        interval = sample_count - last_beat_sample;

        /* 太近的候选不接受 */
        if (interval < 30)
        {
            return 0;
        }

        last_interval = interval;
        last_beat_sample = sample_count;

        /* 间隔过长：清空平均，从本次重新计时 */
        if (interval > 200)
        {
			abnormal_count = 0;
            current_bpm = 0;
            interval_sum = 0;
            interval_index = 0;
            interval_count = 0;

            for (i = 0; i < HR_AVG_COUNT; i++)
            {
                interval_buffer[i] = 0;
            }

            return 0;
        }

		
		/* 已有五次有效间隔后，检查本次是否变化过大 */
		if (interval_count == HR_AVG_COUNT)
		{
			average_interval = interval_sum / interval_count;
		
			if (interval * 100UL < average_interval * 70UL ||
				interval * 100UL > average_interval * 130UL)
			{
				abnormal_count++;
		
				if (abnormal_count >= 3)
				{
					/* 连续异常，放弃旧结果，重新建立检测 */
					HeartRate_Init();
				}
		
				return 0;
			}
		}
		
		/* 本次通过检查 */
		abnormal_count = 0;

        /* 满五次后，减去即将替换的旧间隔 */
        if (interval_count == HR_AVG_COUNT)
        {
            interval_sum -= interval_buffer[interval_index];
        }
        else
        {
            interval_count++;
        }

        /* 保存新间隔 */
        interval_buffer[interval_index] = interval;
        interval_sum += interval;

        interval_index++;
        if (interval_index >= HR_AVG_COUNT)
        {
            interval_index = 0;
        }

        /*
         * 平均间隔 = interval_sum / interval_count
         * BPM = 6000 × interval_count / interval_sum
         */
        numerator = 6000UL * interval_count;

        current_bpm = (uint16_t)(
            (numerator + interval_sum / 2) / interval_sum
        );

        return 1;
    }

    return 0;
}

uint16_t HeartRate_GetBPM(void)
{
    return current_bpm;
}

uint32_t HeartRate_GetInterval(void)
{
    return last_interval;
}
