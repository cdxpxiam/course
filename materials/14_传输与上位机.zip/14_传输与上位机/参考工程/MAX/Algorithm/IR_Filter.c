static unsigned char initialized;
static float baseline,smooth;
void IR_Filter_Reset(void){initialized=0;baseline=0;smooth=0;}
#include "stm32f10x.h"                  // Device header

float IR_Filter(uint32_t ir)
{



    float ac;

    if (initialized == 0)
    {
        baseline = (float)ir;
        smooth = 0.0f;
        initialized = 1;
        return 0.0f;
    }

    /* 去直流 */
    baseline += 0.01f * ((float)ir - baseline);
    ac = (float)ir - baseline;

    /* 平滑 */
    smooth += 0.2f * (ac - smooth);

    return smooth;
}
