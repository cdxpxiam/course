#ifndef HEART_RATE_H
#define HEART_RATE_H

#include "stm32f10x.h"

void HeartRate_Init(void);
uint8_t HeartRate_Process(float sample);
uint16_t HeartRate_GetBPM(void);
uint32_t HeartRate_GetInterval(void);

#endif
