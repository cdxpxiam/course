#include "IR_Motion.h"

/* Tuning values for the current 100-Hz sampling setup. */
#define MOTION_WINDOW_COUNT  50U
#define MOTION_LEVEL         100UL
#define MOTION_CONFIRM_COUNT 2U

static uint32_t previous_ir = 0;
static uint32_t change_sum = 0;
static uint16_t change_count = 0;
static uint8_t initialized = 0;
static uint8_t high_window_count = 0;

void IR_Motion_Init(void)
{
    previous_ir = 0;
    change_sum = 0;
    change_count = 0;
    initialized = 0;
    high_window_count = 0;
}

uint8_t IR_Motion_Process(uint32_t ir, uint8_t finger_present)
{
    uint32_t delta;

    if (finger_present == 0)
    {
        IR_Motion_Init();
        return 0;
    }

    if (initialized == 0)
    {
        previous_ir = ir;
        initialized = 1;
        return 0;
    }

    delta = (ir >= previous_ir) ?
            (ir - previous_ir) : (previous_ir - ir);
    previous_ir = ir;
    change_sum += delta;
    change_count++;

    if (change_count < MOTION_WINDOW_COUNT)
    {
        return 0;
    }

    if (change_sum > MOTION_LEVEL * change_count)
    {
        high_window_count++;
    }
    else
    {
        /* Only consecutive high windows count toward confirmation. */
        high_window_count = 0;
    }

    change_sum = 0;
    change_count = 0;

    if (high_window_count >= MOTION_CONFIRM_COUNT)
    {
        high_window_count = 0;
        return 1;
    }

    return 0;
}
