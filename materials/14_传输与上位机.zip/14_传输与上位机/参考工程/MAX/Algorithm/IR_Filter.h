#ifndef IR_FILTER_H
#define IR_FILTER_H

#include "stm32f10x.h"

float IR_Filter(uint32_t ir);

void IR_Filter_Reset(void);
#endif
