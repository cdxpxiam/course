/* Stage reference implementation; compiled separately, hardware verification pending. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>
#include "MAX30102.h"
#include "Course_MAX.h"
#include "IR_Filter.h"
#include "HeartRate.h"
#include "IR_Motion.h"
#include "HC05.h"
int main(void) {
    uint8_t id=0,failed=0,value=0;MAX30102_Status status;char line[100];
    uint32_t red=0,ir=0,seq=0,now=0,last_display=0,last_sample=0,last_retry=0;int got;
    float filtered=0;
    uint8_t finger=0;uint16_t settled=0,bpm=0;
    uint8_t motion=0,sensor_fault=0;
    uint32_t last_radio=0,radio_seq=0;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Tick_Init();Delay_Init();
    OLED_Init();Serial_Init();MAX30102_BusInit();
    HeartRate_Init();
    IR_Motion_Init();
    HC05_Init();
    status=MAX30102_ReadReg(0xFF,&id);
    snprintf(line,sizeof(line),"# ID,status=%u,part=0x%02X\r\n",status,id);Serial_SendString(line);
    if(status!=MAX30102_OK || id!=0x15) {OLED_ShowString(1,1,"SENSOR ID FAIL");while(1){}}
    status=Course_Start(&failed);
    if(status) {snprintf(line,sizeof(line),"# CONFIG FAIL,%u,%u\r\n",status,failed);Serial_SendString(line);OLED_ShowString(1,1,"CONFIG FAIL");while(1){}}
    {const uint8_t regs[]={0x08,0x0A,0x0C,0x0D,0x09};const uint8_t expected[]={0,0x27,0x1F,0x1F,3};unsigned i;for(i=0;i<5;i++){status=MAX30102_ReadReg(regs[i],&value);snprintf(line,sizeof(line),"# REG,%02X,%02X,status=%u\r\n",regs[i],value,status);Serial_SendString(line);if(status || value!=expected[i]){OLED_ShowString(1,1,"READBACK FAIL");while(1){}}}}
    Serial_SendString("seq,ms,red,ir,filtered_x100,hr_bpm,hr_valid,state,lost\r\n");last_sample=Tick_Now();
    while(1) {
        now=Tick_Now();got=Course_Poll(&red,&ir);
        if(got<0 || (uint32_t)(now-last_sample)>500U) {
            bpm=0;settled=0;sensor_fault=1;HeartRate_Init();IR_Filter_Reset();IR_Motion_Init();
            OLED_ShowString(4,1,"SENSOR GAP/ERR  ");
            if((uint32_t)(now-last_retry)>1000U){last_retry=now;status=Course_Start(&failed);if(!status)last_sample=now;}
        }
        if(got==1) {last_sample=now;seq++;
            filtered=IR_Filter(ir);
            if(!finger && ir>30000UL) {finger=1;settled=0;HeartRate_Init();IR_Filter_Reset();}
            if(finger && ir<20000UL) {finger=0;settled=0;bpm=0;HeartRate_Init();IR_Filter_Reset();}
            sensor_fault=0;motion=IR_Motion_Process(ir,finger);
            if(motion) {settled=0;bpm=0;HeartRate_Init();IR_Filter_Reset();}
            if(!finger) bpm=0;else if(settled<500U) {settled++;bpm=0;}else {HeartRate_Process(filtered);bpm=HeartRate_GetBPM();}
            snprintf(line,sizeof(line),"%lu,%lu,%lu,%lu,%ld,%u,%u,%u,%lu\r\n",(unsigned long)seq,(unsigned long)now,(unsigned long)red,(unsigned long)ir,(long)(filtered*100.0f),bpm,(unsigned)(finger && settled>=500U && bpm!=0),sensor_fault?4U:(!finger?0U:(settled<500U?1U:(bpm?3U:2U))),(unsigned long)Course_Loss);Serial_SendString(line);
            if((uint32_t)(now-last_display)>=250U){last_display=now;OLED_ShowString(1,1,"RED:");OLED_ShowNum(1,5,red,6);OLED_ShowString(2,1,"IR:");OLED_ShowNum(2,4,ir,6);
                if(bpm){OLED_ShowString(4,1,"HR:000 BPM      ");OLED_ShowNum(4,4,bpm,3);}else OLED_ShowString(4,1,"HR:---          ");
            }
        }
        if((uint32_t)(now-last_radio)>=1000U){uint8_t st=sensor_fault?4U:(!finger?0U:(settled<500U?1U:(bpm?3U:2U)));last_radio=now;HC05_SendMetrics(bpm,0,(uint8_t)(st==3U),0,st,radio_seq++);}
        (void)last_retry;
    }
}
