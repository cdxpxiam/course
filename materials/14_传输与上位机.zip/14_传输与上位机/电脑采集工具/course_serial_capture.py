"""Record text without replacing missing data or mixing measurement protocols."""
import argparse,csv,json,time
from pathlib import Path

def parse(line,kind):
    line=line.strip()
    if not line or line.startswith('#'):return None
    fields=next(csv.reader([line]))
    if fields[0] in ('seq','ms','hr_bpm'):return None
    expected={'max':6,'mkb':17}[kind]
    if len(fields)!=expected:raise ValueError(f'expected {expected} fields, got {len(fields)}')
    if kind=='max':
        hr=int(fields[0]);ox=float(fields[1]);hv=int(fields[2]);ov=int(fields[3]);state=int(fields[4]);seq=int(fields[5])
        if hv not in (0,1) or ov not in (0,1) or state not in range(5):raise ValueError('invalid flags/state')
        if hr<0 or seq<0 or (hv and hr==0):raise ValueError('invalid HR or sequence')
        return {'hr':hr if hv else None,'hr_valid':hv,'spo2':ox if ov else None,'state':state,'sequence':seq}
    numbers=[int(v) for i,v in enumerate(fields) if i!=8]
    if any(v<0 for v in numbers) or fields[8]!='NA':raise ValueError('invalid numeric fields or SpO2 marker')
    if any(int(fields[i]) not in (0,1) for i in [4,5,7]):raise ValueError('invalid flags')
    return {'ms':int(fields[0]),'hr':int(fields[1]) if int(fields[4]) else None,'hr_valid':int(fields[4]),'spo2':None}

def check_file(path,kind):
    good=bad=0
    for line in Path(path).read_text(encoding='utf-8-sig').splitlines():
        try:
            if parse(line,kind) is not None:good+=1
        except (ValueError,OverflowError):bad+=1
    return {'complete_frames':good,'parse_errors':bad,'kind':kind,'source':'user_selected_file','hardware_accuracy_verified':False}

def main():
    p=argparse.ArgumentParser();p.add_argument('--kind',choices=['max','mkb'],required=True);p.add_argument('--check-file');p.add_argument('--port');p.add_argument('--baud',type=int);p.add_argument('--seconds',type=float,default=20);p.add_argument('--output');a=p.parse_args()
    if a.check_file:print(json.dumps(check_file(a.check_file,a.kind),ensure_ascii=False));return
    if not a.port or not a.baud or not a.output:p.error('capture requires --port, --baud, --output')
    if a.seconds<=0:p.error('--seconds must be positive')
    try:import serial
    except ImportError:raise SystemExit('Serial capture requires pyserial; install into your chosen Python environment. File checking uses only the standard library.')
    raw=bytearray()
    with serial.Serial(a.port,a.baud,timeout=0.2) as port:
        end=time.monotonic()+a.seconds
        while time.monotonic()<end:raw.extend(port.read(max(1,port.in_waiting)))
    # Raw bytes are retained. Partial capture boundaries are excluded only in a derived file.
    out=Path(a.output)
    if out.exists() or out.with_suffix(out.suffix+'.bin').exists():raise SystemExit('Choose a new output filename; existing captures are not overwritten.')
    out.with_suffix(out.suffix+'.bin').write_bytes(raw)
    first=raw.find(b'\n');last=raw.rfind(b'\n')
    body=raw[first+1:last+1] if first>=0 and last>first else b''
    out.write_text(body.decode('ascii',errors='replace'),encoding='utf-8')
    result=check_file(out,a.kind);result.update(port=a.port,baud=a.baud,seconds=a.seconds,first_partial_or_complete_line_excluded=True,raw_bytes=len(raw))
    out.with_suffix(out.suffix+'.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
