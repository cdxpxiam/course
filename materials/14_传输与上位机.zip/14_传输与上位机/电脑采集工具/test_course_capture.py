import unittest
from course_serial_capture import parse

class CaptureContract(unittest.TestCase):
    def test_invalid_is_missing(self):
        self.assertIsNone(parse('0,0.0,0,0,1,3','max')['hr'])
    def test_valid_hr(self):
        self.assertEqual(parse('72,0.0,1,0,3,4','max')['hr'],72)
    def test_wrong_protocol_rejected(self):
        with self.assertRaises(ValueError):parse('72,0,1,0,3,4','mkb')
    def test_mkb_independent_hr(self):
        row=parse('2000,72,0,0,1,0,123,1,NA,5,0,0,255,0,0,72,1','mkb')
        self.assertEqual(row['hr'],72);self.assertIsNone(row['spo2'])
    def test_truncation_rejected(self):
        with self.assertRaises(ValueError):parse('72,0.0,1','max')
    def test_header_ignored(self):
        self.assertIsNone(parse('ms,hr_bpm,sys_mmhg','mkb'))
    def test_bad_flag(self):
        with self.assertRaises(ValueError):parse('72,0,7,0,3,4','max')
    def test_no_claimed_oxygen(self):
        self.assertIsNone(parse('72,0.0,1,0,3,4','max')['spo2'])

if __name__=='__main__':unittest.main()
