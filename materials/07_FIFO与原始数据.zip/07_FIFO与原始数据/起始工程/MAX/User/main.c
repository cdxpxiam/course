/* Student starting point. Complete the stage tasks; compare the diff only after attempting. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>
#include "MAX30102.h"
#include "Course_MAX.h"
int main(void) {
    uint8_t id=0,failed=0,value=0;MAX30102_Status status;char line[100];
    uint32_t red=0,ir=0,seq=0,now=0,last_display=0,last_sample=0,last_retry=0;int got;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Tick_Init();Delay_Init();
    OLED_Init();Serial_Init();MAX30102_BusInit();
    status=MAX30102_ReadReg(0xFF,&id);
    snprintf(line,sizeof(line),"# ID,status=%u,part=0x%02X\r\n",status,id);Serial_SendString(line);
    if(status!=MAX30102_OK || id!=0x15) {OLED_ShowString(1,1,"SENSOR ID FAIL");while(1){}}
    status=Course_Start(&failed);
    if(status) {snprintf(line,sizeof(line),"# CONFIG FAIL,%u,%u\r\n",status,failed);Serial_SendString(line);OLED_ShowString(1,1,"CONFIG FAIL");while(1){}}
    {const uint8_t regs[]={0x08,0x0A,0x0C,0x0D,0x09};const uint8_t expected[]={0,0x27,0x1F,0x1F,3};unsigned i;for(i=0;i<5;i++){status=MAX30102_ReadReg(regs[i],&value);snprintf(line,sizeof(line),"# REG,%02X,%02X,status=%u\r\n",regs[i],value,status);Serial_SendString(line);if(status || value!=expected[i]){OLED_ShowString(1,1,"READBACK FAIL");while(1){}}}}
    OLED_ShowString(1,1,"CONFIG OK");while(1){}
}
