/* Stage reference implementation; compiled separately, hardware verification pending. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>
#include "MAX30102.h"
#include "Course_MAX.h"
int main(void) {
    uint8_t id=0,failed=0,value=0;MAX30102_Status status;char line[100];
    uint32_t red=0,ir=0,seq=0,now=0,last_display=0,last_sample=0,last_retry=0;int got;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Tick_Init();Delay_Init();
    OLED_Init();Serial_Init();MAX30102_BusInit();
    status=MAX30102_ReadReg(0xFF,&id);
    snprintf(line,sizeof(line),"# ID,status=%u,part=0x%02X\r\n",status,id);Serial_SendString(line);
    if(status!=MAX30102_OK || id!=0x15) {OLED_ShowString(1,1,"SENSOR ID FAIL");while(1){}}
    OLED_ShowString(1,1,"MAX ID OK");OLED_ShowHexNum(2,1,id,2);while(1){}
}
