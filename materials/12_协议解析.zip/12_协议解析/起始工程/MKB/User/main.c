/* Student starting point. Complete the stage tasks; compare the diff only after attempting. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>

static volatile uint8_t bytes[128];static volatile unsigned head,tail;static volatile uint32_t faults;
void USART2_IRQHandler(void){uint32_t sr=USART2->SR;uint8_t b=(uint8_t)USART2->DR;unsigned n=(head+1U)&127U;
    if(sr&(USART_SR_ORE|USART_SR_FE|USART_SR_NE|USART_SR_PE)){faults++;return;}
    if(sr&USART_SR_RXNE){if(n==tail)faults++;else{bytes[head]=b;head=n;}}}
static void SensorUART(void){GPIO_InitTypeDef g;USART_InitTypeDef u;NVIC_InitTypeDef n;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
    g.GPIO_Pin=GPIO_Pin_2;g.GPIO_Mode=GPIO_Mode_AF_PP;g.GPIO_Speed=GPIO_Speed_50MHz;GPIO_Init(GPIOA,&g);
    g.GPIO_Pin=GPIO_Pin_3;g.GPIO_Mode=GPIO_Mode_IPU;GPIO_Init(GPIOA,&g);USART_StructInit(&u);u.USART_BaudRate=115200;USART_Init(USART2,&u);
    n.NVIC_IRQChannel=USART2_IRQn;n.NVIC_IRQChannelPreemptionPriority=1;n.NVIC_IRQChannelSubPriority=0;n.NVIC_IRQChannelCmd=ENABLE;NVIC_Init(&n);
    USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);USART_Cmd(USART2,ENABLE);}
int main(void){uint32_t last=0,now;unsigned i;char line[40];
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Tick_Init();Delay_Init();
    OLED_Init();Serial_Init();SensorUART();OLED_ShowString(1,1,"MKB RAW UART");Tick_Wait(1000);
    while(1){now=Tick_Now();if((uint32_t)(now-last)>=500U){last=now;Serial_SendString("# TX FD 00 00 00 00 00\r\n");
        for(i=0;i<6;i++){while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET){}USART_SendData(USART2,i==0?0xFD:0);}}
        while(tail!=head){uint8_t b=bytes[tail];tail=(tail+1U)&127U;snprintf(line,sizeof(line),"RX,%lu,%02X\r\n",(unsigned long)now,b);Serial_SendString(line);}
        OLED_ShowNum(2,1,faults,8);}}
