/* Stage reference implementation; compiled separately, hardware verification pending. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>
#include "MBK_Protocol.h"
static unsigned failed;
static void Check(int ok){if(!ok)failed++;}
int main(void){MBK_Parser p;uint8_t out[6];char line[80];
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Tick_Init();Delay_Init();
    OLED_Init();Serial_Init();
    /* SYNTHETIC protocol fixtures, not measurements or calibration values. */
    MBK_Request(0xFD,0,0,0,out);Check(out[0]==0xFD && out[5]==0);
    MBK_ParserStart(&p,0xFD,0);Check(!MBK_ParserFeed(&p,0xAA,1));Check(!MBK_ParserFeed(&p,0xFD,2));
    Check(!MBK_ParserFeed(&p,100,3));Check(!MBK_ParserFeed(&p,70,4));Check(MBK_ParserFeed(&p,60,5));Check(MBK_MetricsValid(p.bytes));
    MBK_ParserStart(&p,0xFC,100);Check(!MBK_ParserFeed(&p,0xFC,101));Check(!MBK_ParserFeed(&p,0,102));
    Check(!MBK_ParserFeed(&p,0xFC,103));Check(MBK_ParserFeed(&p,0xFD,104));Check(p.bytes[2]==0xFC && p.bytes[3]==0xFD);
    MBK_ParserStart(&p,0xFD,200);Check(!MBK_ParserFeed(&p,0xFD,201));Check(MBK_ParserExpired(&p,211));
    MBK_ParserStart(&p,0xFD,0xFFFFFFF0UL);Check(MBK_ParserExpired(&p,0x00000022UL));
    Check(MBK_BPReason(0,0,60)!=0);Check(MBK_BPReason(70,100,60)!=0);
    snprintf(line,sizeof(line),"# SYNTHETIC TEST failures=%u\r\n",failed);Serial_SendString(line);
    OLED_ShowString(1,1,failed?"PARSER FAIL":"PARSER PASS");while(1){}}
