/* Stage reference implementation; compiled separately, hardware verification pending. */
#include "stm32f10x.h"
#include "Tick.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>
#include "MBK0805.h"
#include "Telemetry.h"
int main(void){uint32_t now,last_display=0,last_report=0,last_radio=0;char line[TELEMETRY_BUFFER_SIZE];const MBK_Data *d;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Tick_Init();Delay_Init();
    OLED_Init();Serial_Init();
    Tick_Wait(1000);MBK_Init();
    Serial_SendString("ms,hr_bpm,sys_mmhg,dia_mmhg,hr_valid,bp_valid,ppg,ppg_valid,spo2,replies,timeouts,uart_errors,cal,raw_sys,raw_dia,raw_hr,bp_reason\r\n");
    while(1){now=Tick_Now();MBK_Service(now);now=Tick_Now();d=MBK_GetData();
        if((uint32_t)(now-last_display)>=250U){last_display=now;OLED_ShowString(1,1,"MKB HEART RATE  ");
            if(d->hr_valid && d->metric_seen && (uint32_t)(now-d->metric_time)<=3000U){OLED_ShowString(2,1,"HR:000 BPM      ");OLED_ShowNum(2,4,d->hr,3);}
            else OLED_ShowString(2,1,"HR:---          ");
            OLED_ShowString(3,1,d->hr_valid?"HR FIELD VALID  ":"WAIT/NO REPLY   ");OLED_ShowNum(4,1,d->timeouts,8);}
        if((uint32_t)(now-last_report)>=100U){last_report=now;if(Telemetry_Format(d,now,line,sizeof(line)))Serial_SendString(line);}
        (void)last_radio;
    }
}
